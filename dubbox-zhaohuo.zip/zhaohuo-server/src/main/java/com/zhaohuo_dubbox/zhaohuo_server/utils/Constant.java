package com.zhaohuo_dubbox.zhaohuo_server.utils;

public class Constant {
	/**
	 * 服务ID:分布式部署时修改
	 */
	public static int SERVER_ID = 1;
	
	/**
	 * ID生成时当前时间相对于该值的豪秒数
	 */
	public static final long ID_BEGIN_TIME = 1309449600000L; // 2011-07-01
																// 00:00:00
	
}
